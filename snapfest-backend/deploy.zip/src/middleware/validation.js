import { body, param, query, validationResult } from 'express-validator';

// Handle validation errors
export const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  
  if (!errors.isEmpty()) {
    console.log('🔍 Validation errors:', errors.array());
    
    // Field labels for user-friendly messages
    const fieldLabels = {
      'rating': 'Rating',
      'comment': 'Feedback',
      'feedback': 'Feedback',
      'bookingId': 'Booking',
      'name': 'Name',
      'email': 'Email',
      'phone': 'Phone Number',
      'password': 'Password',
      'eventDate': 'Event Date',
      'location': 'Location',
      'guests': 'Number of Guests'
    };
    
    // Format errors into user-friendly messages
    const formattedErrors = errors.array().map(error => {
      const fieldLabel = fieldLabels[error.path] || error.path;
      let message = error.msg;
      
      // Enhance common messages
      if (message.includes('required')) {
        message = `${fieldLabel} is required. Please fill in this field.`;
      } else if (message.includes('at least')) {
        const match = message.match(/at least (\d+)/);
        if (match) {
          message = `${fieldLabel} must be at least ${match[1]} characters long. Please make it longer.`;
        } else {
          message = `${fieldLabel}: ${error.msg}. Please make it longer.`;
        }
      } else if (message.includes('less than') || message.includes('maximum')) {
        message = `${fieldLabel} is too long. ${error.msg}. Please shorten it.`;
      } else if (message.includes('between')) {
        const match = message.match(/between (\d+) and (\d+)/);
        if (match) {
          message = `${fieldLabel} must be between ${match[1]} and ${match[2]}. Please adjust the value.`;
        } else {
          message = `${fieldLabel}: ${error.msg}. Please adjust the value.`;
        }
      } else if (message.includes('valid')) {
        message = `${fieldLabel} format is invalid. ${error.msg}. Please check the format.`;
      } else {
        message = `${fieldLabel}: ${error.msg}`;
      }
      
      return {
        field: error.path,
        message: message,
        value: error.value
      };
    });
    
    // Create user-friendly main message
    let mainMessage;
    if (formattedErrors.length === 1) {
      mainMessage = formattedErrors[0].message;
    } else {
      mainMessage = `Please fix the following ${formattedErrors.length} errors:\n${formattedErrors.map((err, i) => `${i + 1}. ${err.message}`).join('\n')}`;
    }
    
    return res.status(400).json({
      success: false,
      message: mainMessage,
      errors: formattedErrors
    });
  }
  
  next();
};

// User registration validation
export const validateUserRegistration = [
  body('name')
    .trim()
    .notEmpty()
    .withMessage('Name is required')
    .isLength({ min: 2, max: 50 })
    .withMessage('Name must be between 2 and 50 characters'),
  
  body('email')
    .trim()
    .notEmpty()
    .withMessage('Email is required')
    .isEmail()
    .withMessage('Please provide a valid email address')
    .normalizeEmail(),
  
  body('phone')
    .trim()
    .notEmpty()
    .withMessage('Phone number is required')
    .customSanitizer((value) => {
      // Remove all non-digit characters (hyphens, spaces, parentheses, etc.)
      return value ? value.replace(/\D/g, '') : value;
    })
    .matches(/^[6-9]\d{9}$/)
    .withMessage('Please provide a valid 10-digit phone number'),
  
  body('password')
    .notEmpty()
    .withMessage('Password is required')
    .isLength({ min: 6 })
    .withMessage('Password must be at least 6 characters long')
    .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/)
    .withMessage('Password must contain at least one lowercase letter, one uppercase letter, and one number'),
  
  body('role')
    .optional()
    .isIn(['user', 'vendor', 'admin'])
    .withMessage('Role must be user, vendor, or admin'),
  
  handleValidationErrors
];

// User login validation
export const validateUserLogin = [
  body('email')
    .trim()
    .notEmpty()
    .withMessage('Email is required')
    .isEmail()
    .withMessage('Please provide a valid email address')
    .normalizeEmail(),
  
  body('password')
    .notEmpty()
    .withMessage('Password is required'),
  
  handleValidationErrors
];

// Password change validation
export const validatePasswordChange = [
  body('currentPassword')
    .notEmpty()
    .withMessage('Current password is required'),
  
  body('newPassword')
    .notEmpty()
    .withMessage('New password is required')
    .isLength({ min: 6 })
    .withMessage('New password must be at least 6 characters long')
    .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/)
    .withMessage('New password must contain at least one lowercase letter, one uppercase letter, and one number'),
  
  handleValidationErrors
];

// Password reset validation
export const validatePasswordReset = [
  body('email')
    .trim()
    .notEmpty()
    .withMessage('Email is required')
    .isEmail()
    .withMessage('Please provide a valid email address')
    .normalizeEmail(),
  
  handleValidationErrors
];

// Password reset confirm validation
export const validatePasswordResetConfirm = [
  body('token')
    .notEmpty()
    .withMessage('Reset token is required'),
  
  body('newPassword')
    .notEmpty()
    .withMessage('New password is required')
    .isLength({ min: 6 })
    .withMessage('New password must be at least 6 characters long')
    .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/)
    .withMessage('New password must contain at least one lowercase letter, one uppercase letter, and one number'),
  
  handleValidationErrors
];

// Profile update validation
export const validateProfileUpdate = [
  body('name')
    .optional()
    .trim()
    .isLength({ min: 2, max: 50 })
    .withMessage('Name must be between 2 and 50 characters'),
  
  body('phone')
    .optional()
    .trim()
    .customSanitizer((value) => {
      // Remove all non-digit characters (hyphens, spaces, parentheses, etc.)
      return value ? value.replace(/\D/g, '') : value;
    })
    .matches(/^[6-9]\d{9}$/)
    .withMessage('Please provide a valid 10-digit phone number'),
  
  body('profileImage')
    .optional()
    .isURL()
    .withMessage('Profile image must be a valid URL'),
  
  body('address')
    .optional()
    .custom((value) => {
      if (value && typeof value !== 'object') {
        throw new Error('Address must be an object');
      }
      return true;
    }),
  
  body('address.street')
    .optional()
    .trim()
    .isLength({ max: 200 })
    .withMessage('Street address must be less than 200 characters'),
  
  body('address.city')
    .optional()
    .trim()
    .isLength({ max: 100 })
    .withMessage('City must be less than 100 characters'),
  
  body('address.state')
    .optional()
    .trim()
    .isLength({ max: 100 })
    .withMessage('State must be less than 100 characters'),
  
  body('address.pincode')
    .optional()
    .trim()
    .matches(/^\d{6,7}$/)
    .withMessage('Pincode must be a 6 or 7-digit number'),
  
  body('address.country')
    .optional()
    .trim()
    .isLength({ max: 100 })
    .withMessage('Country must be less than 100 characters'),
  
  handleValidationErrors
];

// Package validation
export const validatePackage = [
  body('title')
    .trim()
    .notEmpty()
    .withMessage('Package title is required')
    .isLength({ min: 3, max: 100 })
    .withMessage('Title must be between 3 and 100 characters'),
  
  body('category')
    .notEmpty()
    .withMessage('Category is required')
    .isIn(['WEDDING', 'BIRTHDAY', 'HALDI', 'CORPORATE', 'BABY_SHOWER'])
    .withMessage('Category must be one of: WEDDING, BIRTHDAY, HALDI, CORPORATE, BABY_SHOWER'),
  
  body('basePrice')
    .notEmpty()
    .withMessage('Base price is required')
    .isNumeric()
    .withMessage('Base price must be a number')
    .isFloat({ min: 0 })
    .withMessage('Base price must be a positive number'),
  
  body('description')
    .trim()
    .notEmpty()
    .withMessage('Description is required')
    .isLength({ min: 10, max: 1000 })
    .withMessage('Description must be between 10 and 1000 characters'),
  
  handleValidationErrors
];

// Booking validation
export const validateBooking = [
  // Either packageId or beatBloomId is required, but not both
  body().custom((value) => {
    const { packageId, beatBloomId } = value;
    
    if (!packageId && !beatBloomId) {
      throw new Error('Either packageId or beatBloomId is required');
    }
    
    if (packageId && beatBloomId) {
      throw new Error('Cannot provide both packageId and beatBloomId');
    }
    
    return true;
  }),
  
  body('packageId')
    .optional()
    .isMongoId()
    .withMessage('Invalid package ID'),
  
  body('beatBloomId')
    .optional()
    .isMongoId()
    .withMessage('Invalid BeatBloom ID'),
  
  body('eventDate')
    .notEmpty()
    .withMessage('Event date is required')
    .isISO8601()
    .withMessage('Event date must be a valid date')
    .custom((value) => {
      const eventDate = new Date(value);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      if (eventDate < today) {
        throw new Error('Event date cannot be in the past');
      }
      return true;
    }),
  
  body('location')
    .trim()
    .notEmpty()
    .withMessage('Location is required')
    .isLength({ min: 5, max: 200 })
    .withMessage('Location must be between 5 and 200 characters'),
  
  handleValidationErrors
];

// Payment validation
export const validatePayment = [
  body('bookingId')
    .notEmpty()
    .withMessage('Booking ID is required')
    .isMongoId()
    .withMessage('Invalid booking ID'),
  
  body('method')
    .notEmpty()
    .withMessage('Payment method is required')
    .isIn(['online', 'cash'])
    .withMessage('Payment method must be online or cash'),
  
  body('amount')
    .notEmpty()
    .withMessage('Amount is required')
    .isNumeric()
    .withMessage('Amount must be a number')
    .isFloat({ min: 0 })
    .withMessage('Amount must be a positive number'),
  
  handleValidationErrors
];

// Beat & Bloom validation
export const validateBeatBloom = [
  body('title')
    .trim()
    .notEmpty()
    .withMessage('Title is required')
    .isLength({ min: 3, max: 100 })
    .withMessage('Title must be between 3 and 100 characters'),
  
  body('category')
    .notEmpty()
    .withMessage('Category is required')
    .isIn(['ENTERTAINMENT', 'DECOR', 'CATERING', 'PHOTOGRAPHY', 'MAKEUP', 'LIGHTING', 'STAFF', 'OTHER'])
    .withMessage('Category must be one of: ENTERTAINMENT, DECOR, CATERING, PHOTOGRAPHY, MAKEUP, LIGHTING, STAFF, OTHER'),
  
  body('description')
    .trim()
    .notEmpty()
    .withMessage('Description is required')
    .isLength({ min: 10, max: 1000 })
    .withMessage('Description must be between 10 and 1000 characters'),
  
  body('price')
    .notEmpty()
    .withMessage('Price is required')
    .isNumeric()
    .withMessage('Price must be a number')
    .isFloat({ min: 0 })
    .withMessage('Price must be a positive number'),
  
  body('features')
    .optional()
    .isArray()
    .withMessage('Features must be an array'),
  
  body('images')
    .optional()
    .isArray()
    .withMessage('Images must be an array'),
  
  body('isActive')
    .optional()
    .isBoolean()
    .withMessage('isActive must be a boolean'),
  
  handleValidationErrors
];

// Beat & Bloom update validation
export const validateBeatBloomUpdate = [
  body('title')
    .optional()
    .trim()
    .isLength({ min: 3, max: 100 })
    .withMessage('Title must be between 3 and 100 characters'),
  
  body('category')
    .optional()
    .isIn(['ENTERTAINMENT', 'DECOR', 'CATERING', 'PHOTOGRAPHY', 'MAKEUP', 'LIGHTING', 'STAFF', 'OTHER'])
    .withMessage('Category must be one of: ENTERTAINMENT, DECOR, CATERING, PHOTOGRAPHY, MAKEUP, LIGHTING, STAFF, OTHER'),
  
  body('description')
    .optional()
    .trim()
    .isLength({ min: 10, max: 1000 })
    .withMessage('Description must be between 10 and 1000 characters'),
  
  body('price')
    .optional()
    .isNumeric()
    .withMessage('Price must be a number')
    .isFloat({ min: 0 })
    .withMessage('Price must be a positive number'),
  
  body('features')
    .optional()
    .isArray()
    .withMessage('Features must be an array'),
  
  body('images')
    .optional()
    .isArray()
    .withMessage('Images must be an array'),
  
  body('isActive')
    .optional()
    .isBoolean()
    .withMessage('isActive must be a boolean'),
  
  handleValidationErrors
];

// Venue validation
export const validateVenue = [
  body('name')
    .trim()
    .notEmpty()
    .withMessage('Venue name is required')
    .isLength({ min: 3, max: 100 })
    .withMessage('Name must be between 3 and 100 characters'),
  
  body('location')
    .trim()
    .notEmpty()
    .withMessage('Location is required')
    .isLength({ min: 5, max: 200 })
    .withMessage('Location must be between 5 and 200 characters'),
  
  body('capacity')
    .notEmpty()
    .withMessage('Capacity is required')
    .isInt({ min: 1 })
    .withMessage('Capacity must be a positive integer'),
  
  body('pricePerDay')
    .notEmpty()
    .withMessage('Price per day is required')
    .isNumeric()
    .withMessage('Price must be a number')
    .isFloat({ min: 0 })
    .withMessage('Price must be a positive number'),
  
  body('amenities')
    .optional()
    .isArray()
    .withMessage('Amenities must be an array'),
  
  body('images')
    .optional()
    .isArray()
    .withMessage('Images must be an array'),
  
  body('rating')
    .optional()
    .isFloat({ min: 0, max: 5 })
    .withMessage('Rating must be between 0 and 5'),
  
  body('isActive')
    .optional()
    .isBoolean()
    .withMessage('isActive must be a boolean'),
  
  handleValidationErrors
];

// Venue update validation
export const validateVenueUpdate = [
  body('name')
    .optional()
    .trim()
    .isLength({ min: 3, max: 100 })
    .withMessage('Name must be between 3 and 100 characters'),
  
  body('location')
    .optional()
    .trim()
    .isLength({ min: 5, max: 200 })
    .withMessage('Location must be between 5 and 200 characters'),
  
  body('capacity')
    .optional()
    .isInt({ min: 1 })
    .withMessage('Capacity must be a positive integer'),
  
  body('pricePerDay')
    .optional()
    .isNumeric()
    .withMessage('Price must be a number')
    .isFloat({ min: 0 })
    .withMessage('Price must be a positive number'),
  
  body('amenities')
    .optional()
    .isArray()
    .withMessage('Amenities must be an array'),
  
  body('images')
    .optional()
    .isArray()
    .withMessage('Images must be an array'),
  
  body('rating')
    .optional()
    .isFloat({ min: 0, max: 5 })
    .withMessage('Rating must be between 0 and 5'),
  
  body('isActive')
    .optional()
    .isBoolean()
    .withMessage('isActive must be a boolean'),
  
  handleValidationErrors
];

// MongoDB ObjectId validation
export const validateObjectId = (paramName) => [
  param(paramName)
    .isMongoId()
    .withMessage(`Invalid ${paramName}`),
  
  handleValidationErrors
];

// Pagination validation
export const validatePagination = [
  query('page')
    .optional()
    .isInt({ min: 1 })
    .withMessage('Page must be a positive integer'),
  
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('Limit must be between 1 and 100'),
  
  handleValidationErrors
];

// Search validation
export const validateSearch = [
  query('q')
    .optional()
    .trim()
    .isLength({ min: 2, max: 100 })
    .withMessage('Search query must be between 2 and 100 characters'),
  
  handleValidationErrors
];

// Cart item validation - Supports both Packages and BeatBloom
export const validateCartItem = [
  // Validate itemType (optional, defaults to 'package' for backward compatibility)
  body('itemType')
    .optional()
    .isIn(['package', 'beatbloom'])
    .withMessage('itemType must be either "package" or "beatbloom"'),
  
  // Conditional validation: packageId required for packages, beatBloomId for beatbloom
  body().custom((value, { req }) => {
    const itemType = req.body.itemType || 'package'; // Default to 'package' for backward compatibility
    
    if (itemType === 'package') {
      if (!value.packageId) {
        throw new Error('Package ID is required for package items');
      }
      // Validate MongoDB ID format
      const mongoIdRegex = /^[0-9a-fA-F]{24}$/;
      if (!mongoIdRegex.test(value.packageId)) {
        throw new Error('Invalid package ID format');
      }
    } else if (itemType === 'beatbloom') {
      if (!value.beatBloomId) {
        throw new Error('BeatBloom ID is required for beatbloom items');
      }
      // Validate MongoDB ID format
      const mongoIdRegex = /^[0-9a-fA-F]{24}$/;
      if (!mongoIdRegex.test(value.beatBloomId)) {
        throw new Error('Invalid BeatBloom ID format');
      }
    }
    
    return true;
  }),
  
  body('eventDate')
    .notEmpty()
    .withMessage('Event date is required')
    .custom((value) => {
      // Accept both YYYY-MM-DD format (from HTML date input) and ISO8601
      const dateRegex = /^\d{4}-\d{2}-\d{2}/;
      if (!dateRegex.test(value)) {
        throw new Error('Event date must be in YYYY-MM-DD format');
      }
      
      const eventDate = new Date(value);
      if (isNaN(eventDate.getTime())) {
        throw new Error('Event date must be a valid date');
      }
      
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      eventDate.setHours(0, 0, 0, 0);
      
      if (eventDate < today) {
        throw new Error('Event date cannot be in the past');
      }
      return true;
    }),
  
  body('location')
    .trim()
    .notEmpty()
    .withMessage('Location is required')
    .isLength({ min: 5, max: 200 })
    .withMessage('Location must be between 5 and 200 characters'),
  
  body('guests')
    .optional()
    .isInt({ min: 1 })
    .withMessage('Guests must be a positive integer'),
  
  handleValidationErrors
];

// Review validation
export const validateReview = [
  body('bookingId')
    .optional()
    .isMongoId()
    .withMessage('Invalid booking ID format. Please select a valid booking.'),
  
  body('rating')
    .notEmpty()
    .withMessage('Rating is required. Please select a rating from 1 to 5 stars.')
    .isInt({ min: 1, max: 5 })
    .withMessage('Rating must be between 1 and 5 stars. Please select a valid rating.'),
  
  body('comment')
    .optional()
    .trim()
    .isLength({ max: 500 })
    .withMessage('Comment must be less than 500 characters. Please shorten your comment.'),
  
  body('feedback')
    .optional()
    .trim()
    .isLength({ min: 10, max: 1000 })
    .withMessage('Feedback must be between 10 and 1000 characters. Please provide more details (at least 10 characters) and keep it under 1000 characters.'),
  
  handleValidationErrors
];

// Forgot password validation
export const validateForgotPassword = [
  body('email')
    .trim()
    .notEmpty()
    .withMessage('Email is required')
    .isEmail()
    .withMessage('Please provide a valid email address')
    .normalizeEmail(),
  
  handleValidationErrors
];

// Reset password validation
export const validateResetPassword = [
  body('token')
    .notEmpty()
    .withMessage('Reset token is required'),
  
  body('newPassword')
    .notEmpty()
    .withMessage('New password is required')
    .isLength({ min: 6 })
    .withMessage('Password must be at least 6 characters long'),
  
  handleValidationErrors
];

// Search save validation
export const validateSearchSave = [
  body('searchQuery')
    .optional()
    .trim()
    .isLength({ min: 1, max: 100 })
    .withMessage('Search query must be between 1 and 100 characters'),
  
  body('filters')
    .optional()
    .isObject()
    .withMessage('Filters must be an object'),
  
  handleValidationErrors
];

// Booking status validation
export const validateBookingStatus = [
  body('status')
    .notEmpty()
    .withMessage('Status is required')
    .isIn(['PENDING_PARTIAL_PAYMENT', 'PARTIALLY_PAID', 'ASSIGNED', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED'])
    .withMessage('Invalid booking status'),
  
  handleValidationErrors
];
